/* A polyfill for browsers that don't support ligatures. */
/* The script tag referring to this file must be placed before the ending body tag. */

/* To provide support for elements dynamically added, this script adds
   method 'icomoonLiga' to the window object. You can pass element references to this method.
*/
(function () {
    'use strict';
    function supportsProperty(p) {
        var prefixes = ['Webkit', 'Moz', 'O', 'ms'],
            i,
            div = document.createElement('div'),
            ret = p in div.style;
        if (!ret) {
            p = p.charAt(0).toUpperCase() + p.substr(1);
            for (i = 0; i < prefixes.length; i += 1) {
                ret = prefixes[i] + p in div.style;
                if (ret) {
                    break;
                }
            }
        }
        return ret;
    }
    var icons;
    if (!supportsProperty('fontFeatureSettings')) {
        icons = {
            'alias_arrow': '&#xe918;',
            'api': '&#xe91a;',
            'api_ondark': '&#xe919;',
            'application': '&#xe91b;',
            'bucket': '&#xe91c;',
            'cluster_analysis': '&#xe900;',
            'column': '&#xe91d;',
            'connected_identity': '&#xe91e;',
            'data_preparation': '&#xe901;',
            'data_source': '&#xe91f;',
            'database': '&#xe926;',
            'database_changed': '&#xe920;',
            'database_edit': '&#xe921;',
            'database_foreign': '&#xe922;',
            'database_lab': '&#xe923;',
            'database_search': '&#xe924;',
            'database_synced': '&#xe925;',
            'disconnect': '&#xe927;',
            'dock_right': '&#xe928;',
            'engine': '&#xe929;',
            'file': '&#xe930;',
            'file_changed': '&#xe92a;',
            'file_edit': '&#xe92b;',
            'file_foreign': '&#xe92c;',
            'file_lab': '&#xe92d;',
            'file_search': '&#xe92e;',
            'file_synced': '&#xe92f;',
            'formula': '&#xe931;',
            'lab': '&#xe932;',
            'loader_dots': '&#xe903;',
            'machine_learning': '&#xe904;',
            'machine_learning_ondark': '&#xe933;',
            'model': '&#xe937;',
            'model_configuration_ondark': '&#xe935;',
            'model_configuration': '&#xe934;',
            'model_ondark': '&#xe936;',
            'no_results': '&#xe938;',
            'node_branch': '&#xe905;',
            'node_merge': '&#xe906;',
            'node_notification': '&#xe93a;',
            'node_notification_ondark': '&#xe939;',
            'object_storage': '&#xe93c;',
            'object_storage_ondark': '&#xe93b;',
            'operations': '&#xe93d;',
            'operators_divide': '&#xe93e;',
            'operators_equals': '&#xe907;',
            'operators_greater_than': '&#xe93f;',
            'operators_greater_than_or_equal': '&#xe908;',
            'operators_less_than': '&#xe940;',
            'operators_less_than_or_equal': '&#xe909;',
            'operators_multiply': '&#xe90a;',
            'operators_not_equal': '&#xe90b;',
            'operators_parentheses': '&#xe941;',
            'operators_parenthesis_left': '&#xe942;',
            'operators_parenthesis_right': '&#xe943;',
            'operators_subtract': '&#xe90c;',
            'outbound_campaign_manager': '&#xe90d;',
            'product_analyst': '&#xe944;',
            'product_console': '&#xe945;',
            'product_editor': '&#xe946;',
            'resize_northeast': '&#xe947;',
            'resize_northwest': '&#xe948;',
            'resize_southeast': '&#xe949;',
            'resize_southwest': '&#xe94a;',
            'rules': '&#xe950;',
            'rules_insert': '&#xe94c;',
            'rules_insert_ondark': '&#xe94b;',
            'rules_ondark': '&#xe94d;',
            'rules_select': '&#xe94f;',
            'rules_select_ondark': '&#xe94e;',
            'script': '&#xe952;',
            'script_macro': '&#xe90f;',
            'script_macro_ondark': '&#xe90e;',
            'script_ondark': '&#xe951;',
            'script_sql': '&#xe911;',
            'script_sql_ondark': '&#xe910;',
            'script_stored_procedure': '&#xe913;',
            'script_stored_procedure_ondark': '&#xe912;',
            'segmentation': '&#xe953;',
            'server': '&#xe95a;',
            'server_changed': '&#xe954;',
            'server_edit': '&#xe955;',
            'server_foreign': '&#xe956;',
            'server_lab': '&#xe957;',
            'server_search': '&#xe958;',
            'server_synced': '&#xe959;',
            'sftp': '&#xe95c;',
            'sftp_ondark': '&#xe95b;',
            'table': '&#xe963;',
            'table_changed': '&#xe95d;',
            'table_edit': '&#xe95e;',
            'table_foreign': '&#xe95f;',
            'table_lab': '&#xe960;',
            'table_search': '&#xe961;',
            'table_synced': '&#xe962;',
            'teradata': '&#xe964;',
            'text_analysis': '&#xe965;',
            'undock': '&#xe966;',
            'variable': '&#xe915;',
            'variable_ondark': '&#xe914;',
            'view_sankey': '&#xe916;',
            'wand': '&#xe967;',
            'workflow': '&#xe917;',
          '0': 0
        };
        delete icons['0'];
        window.icomoonLiga = function (els) {
            var classes,
                el,
                i,
                innerHTML,
                key;
            els = els || document.getElementsByTagName('*');
            if (!els.length) {
                els = [els];
            }
            for (i = 0; ; i += 1) {
                el = els[i];
                if (!el) {
                    break;
                }
                classes = el.className;
                if (/icon-/.test(classes)) {
                    innerHTML = el.innerHTML;
                    if (innerHTML && innerHTML.length > 1) {
                        for (key in icons) {
                            if (icons.hasOwnProperty(key)) {
                                innerHTML = innerHTML.replace(new RegExp(key, 'g'), icons[key]);
                            }
                        }
                        el.innerHTML = innerHTML;
                    }
                }
            }
        };
        window.icomoonLiga();
    }
}());
